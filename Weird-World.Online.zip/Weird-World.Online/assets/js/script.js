function toggleMenu() {
    const dropdownMenu = document.querySelector('.dropdown-menu');
    dropdownMenu.classList.toggle('show');
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('.menu-icon').addEventListener('click', toggleMenu);
});
